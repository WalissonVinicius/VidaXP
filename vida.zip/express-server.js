// Servidor Express personalizado para a Discloud
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 80;

// Configurar cabeçalhos MIME
const setCustomMimeTypes = (res, path) => {
  if (path.endsWith('.js')) {
    res.set('Content-Type', 'application/javascript');
  } else if (path.endsWith('.mjs')) {
    res.set('Content-Type', 'application/javascript');
  } else if (path.endsWith('.css')) {
    res.set('Content-Type', 'text/css');
  } else if (path.endsWith('.json')) {
    res.set('Content-Type', 'application/json');
  } else if (path.endsWith('.svg')) {
    res.set('Content-Type', 'image/svg+xml');
  }
  return res;
};

// Middleware para definir cabeçalhos MIME para arquivos estáticos
app.use((req, res, next) => {
  res = setCustomMimeTypes(res, req.path);
  next();
});

// Servir arquivos estáticos da pasta dist
app.use(express.static(path.join(__dirname, 'dist'), {
  setHeaders: (res, path) => {
    setCustomMimeTypes(res, path);
  }
}));

// Redirecionar todas as rotas para index.html (para SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

// Iniciar o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
}); 