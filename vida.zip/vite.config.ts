import path from 'path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  build: {
    rollupOptions: {
      output: {
        format: 'umd',
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash].[ext]',
        name: 'VidaXP',
        manualChunks: undefined
      }
    },
    minify: false,
    sourcemap: false,
    modulePreload: {
      polyfill: false
    }
  },
  server: {
    headers: {
      'Content-Type': 'application/javascript'
    }
  },
  experimental: {
    renderBuiltUrl(filename) {
      return '/' + filename;
    }
  }
});
